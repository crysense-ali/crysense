"""Audio feature extraction shared by training and the web app.
Features are interpretable acoustic descriptors (pitch, frequency content,
intensity, duration, spectral/MFCC patterns) summarised per clip."""
import numpy as np
import librosa

SR = 8000          # dataset is 8 kHz; uploads are resampled to this
MAX_SEC = 12.0     # cap analysis length

def load_audio(path):
    y, _ = librosa.load(path, sr=SR, mono=True, duration=MAX_SEC)
    return y

def _stats(x, name):
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        x = np.zeros(1)
    return {f"{name}_mean": x.mean(), f"{name}_std": x.std(),
            f"{name}_min": x.min(), f"{name}_max": x.max()}

def extract_features(y):
    """Returns (feature_dict). Raises ValueError if audio is too short/silent."""
    if y.size < SR * 0.5:
        raise ValueError("Audio is shorter than 0.5 seconds.")
    peak = np.max(np.abs(y))
    if peak < 1e-4:
        raise ValueError("Audio is silent.")
    y = y / peak
    f = {}
    # Intensity (RMS) and cry duration (voiced/active share)
    rms = librosa.feature.rms(y=y)[0]
    f.update(_stats(rms, "rms"))
    thr = 0.1 * rms.max()
    active = rms > thr
    f["active_ratio"] = active.mean()
    f["duration_s"] = y.size / SR
    f["active_duration_s"] = active.sum() * 512 / SR
    # Pitch (F0) via YIN, infant cries are high pitched (~250-700 Hz)
    f0 = librosa.yin(y, fmin=150, fmax=1200, sr=SR, frame_length=1024)
    rms_f = librosa.feature.rms(y=y, frame_length=1024, hop_length=256)[0]
    n = min(len(f0), len(rms_f))
    voiced = rms_f[:n] > 0.1 * rms_f.max()      # pitch only counted on active frames
    f0v = f0[:n][voiced]
    f["voiced_ratio"] = float(voiced.mean()) if n else 0.0
    f.update(_stats(f0v, "f0"))
    f["f0_range"] = float(f0v.max() - f0v.min()) if f0v.size else 0.0
    # Frequency content
    S = np.abs(librosa.stft(y, n_fft=512, hop_length=256))
    f.update(_stats(librosa.feature.spectral_centroid(S=S, sr=SR)[0], "centroid"))
    f.update(_stats(librosa.feature.spectral_bandwidth(S=S, sr=SR)[0], "bandwidth"))
    f.update(_stats(librosa.feature.spectral_rolloff(S=S, sr=SR)[0], "rolloff"))
    f.update(_stats(librosa.feature.spectral_flatness(S=S)[0], "flatness"))
    f.update(_stats(librosa.feature.zero_crossing_rate(y)[0], "zcr"))
    # Audio patterns: MFCC (+ delta) summary
    mf = librosa.feature.mfcc(y=y, sr=SR, n_mfcc=13, n_fft=512, hop_length=256, n_mels=40)
    for i in range(13):
        f[f"mfcc{i}_mean"] = mf[i].mean()
        f[f"mfcc{i}_std"] = mf[i].std()
    d = librosa.feature.delta(mf)
    for i in range(13):
        f[f"dmfcc{i}_std"] = d[i].std()
    return f

def feature_vector(y, names=None):
    f = extract_features(y)
    names = names or sorted(f)
    return np.array([f[n] for n in names], dtype=float), f
