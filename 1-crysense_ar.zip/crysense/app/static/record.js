// Records from the microphone and encodes 16-bit mono WAV in the browser (no server-side codec needed).
const $ = id => document.getElementById(id);
const AR = document.documentElement.lang === 'ar';
const M = {
 mic: AR ? 'الميكروفون غير متاح. اسمح بالوصول إليه (يحتاج https أو localhost) أو ارفع ملفًا بدلًا من ذلك.' : 'Microphone not available. Allow access (needs https or localhost) or upload a file instead.',
 stop: AR ? 'إيقاف التسجيل' : 'Stop recording', again: AR ? 'سجّل مرة أخرى' : 'Record again', s: AR ? ' ث' : ' s',
 got: (d) => AR ? 'تم التقاط التسجيل بنجاح ('+d+' ث). جاهز للتحليل.' : 'Recording captured successfully ('+d+' s). Ready to analyze.',
 up: (n,k) => AR ? 'تم رفع ملف الصوت بنجاح: '+n+' ('+k+' ك.ب). جاهز للتحليل.' : 'Audio file uploaded successfully: '+n+' ('+k+' KB). Ready to analyze.',
 pls: AR ? 'من فضلك سجّل البكاء أو ارفع تسجيلًا أولًا.' : 'Please record or upload a cry first.',
 busy: AR ? 'جارٍ التحليل...' : 'Analyzing...'
};
let ctx, stream, proc, chunks = [], recording = false, t0, rate;
function setStatus(t){ const s=$('status'); s.hidden=false; s.textContent=t; }
function encodeWav(buf, sr){
  const n=buf.length, b=new ArrayBuffer(44+n*2), v=new DataView(b);
  const w=(o,s)=>[...s].forEach((c,i)=>v.setUint8(o+i,c.charCodeAt(0)));
  w(0,'RIFF');v.setUint32(4,36+n*2,true);w(8,'WAVE');w(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);
  v.setUint32(24,sr,true);v.setUint32(28,sr*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);w(36,'data');v.setUint32(40,n*2,true);
  for(let i=0;i<n;i++){const x=Math.max(-1,Math.min(1,buf[i]));v.setInt16(44+i*2,x<0?x*0x8000:x*0x7fff,true);}
  return new Blob([v],{type:'audio/wav'});
}
function draw(data){ const c=$('wave'),g=c.getContext('2d'); c.width=c.clientWidth; g.clearRect(0,0,c.width,80); g.strokeStyle='#3b82c4'; g.beginPath();
  data.forEach((x,i)=>{const X=i/data.length*c.width; g.lineTo(X,40+x*38);}); g.stroke(); }
$('rec').onclick = async () => {
  if(!recording){
    try{ stream = await navigator.mediaDevices.getUserMedia({audio:true}); }catch(e){ setStatus(M.mic); return; }
    ctx = new (window.AudioContext||window.webkitAudioContext)(); rate = ctx.sampleRate; chunks=[];
    const src = ctx.createMediaStreamSource(stream); proc = ctx.createScriptProcessor(4096,1,1);
    proc.onaudioprocess = e => { const d=new Float32Array(e.inputBuffer.getChannelData(0)); chunks.push(d); draw(d); $('timer').textContent=((Date.now()-t0)/1000).toFixed(0)+M.s; if(Date.now()-t0>15000) $('rec').click(); };
    src.connect(proc); proc.connect(ctx.destination); t0=Date.now(); recording=true; $('rec').textContent=M.stop;
  } else {
    recording=false; proc.disconnect(); stream.getTracks().forEach(t=>t.stop()); ctx.close(); $('rec').textContent=M.again;
    const len=chunks.reduce((a,c)=>a+c.length,0), all=new Float32Array(len); let o=0; chunks.forEach(c=>{all.set(c,o);o+=c.length;});
    const file=new File([encodeWav(all,rate)],'recording.wav',{type:'audio/wav'}); const dt=new DataTransfer(); dt.items.add(file); $('file').files=dt.files;
    setStatus(M.got((len/rate).toFixed(1)));
  }
};
$('file').onchange = () => { const f=$('file').files[0]; if(f) setStatus(M.up(f.name,(f.size/1024).toFixed(0))); };
$('f').onsubmit = e => { if(!$('file').files.length){ e.preventDefault(); setStatus(M.pls); } else { $('go').textContent=M.busy; $('go').disabled=true; } };
