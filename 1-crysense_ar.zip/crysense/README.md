# CrySense AI: Infant Cry Analysis & Responsive Care Assistant

Research prototype (web app + real audio ML pipeline) for a pediatric nursing graduation project.
**Not a medical device. It does not diagnose.** Cry patterns are model-based possibilities, not causes.

## Run it
```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app/app.py                                       # open http://localhost:5000
```
A trained model is already included (`model/crysense_model.joblib`). Microphone recording works on `localhost` or https.
MP3/WAV upload works directly; for odd formats (m4a, webm) install `ffmpeg`.

## Retrain / re-evaluate
```bash
bash scripts/get_dataset.sh                             # downloads Donate-a-Cry corpus (ODbL)
python train.py data/donateacry-corpus/donateacry_corpus_cleaned_and_updated_data
```
Writes `model/crysense_model.joblib`, `model/metrics.json`, `model/confusion_matrix.png`.

## What is inside
| Path | Purpose |
|---|---|
| `app/app.py`, `app/templates`, `app/static` | Flask web app: Home, baby info form, record/upload, results, safety page, about-the-model |
| `app/analysis.py` | Loads audio, extracts features, runs the model, applies the "uncertain" gate |
| `crysense_features.py` | Pitch (YIN), spectral centroid/bandwidth/rolloff/flatness, intensity (RMS), active cry duration, ZCR, MFCC + deltas |
| `train.py` | Dataset loading, grouped cross-validation, metrics, confusion matrix, model export |
| `guidance.py` | Caregiver guidance, danger signs, sources (edit here to change wording or add Arabic) |
| `docs/DATASET_AND_METHOD.md` | Dataset, method, evaluation, limits, references |

## Honest status of the AI model
- Dataset: Donate-a-Cry corpus, 457 clips: hunger 382, discomfort 35 (incl. 8 burping), tiredness 24, pain/distress 16. Labels were self-reported by parents, not clinicians.
- Evaluation: 5-fold stratified cross-validation, grouped by recording app-install so the same family never appears in both train and test.
- Result: overall accuracy 0.84, which equals always guessing "hunger" (0.84). Balanced accuracy 0.25 = chance for 4 classes. **The model currently cannot separate the classes.** The pipeline is real and runs end to end, but this dataset and these features are not enough for a reliable classifier.
- Because of that, the app reports a pattern only when its probability clearly beats the class base rate; otherwise it shows **Unknown / Uncertain** (about 99% of cross-validated clips). This is deliberate: a confident-looking wrong answer is worse than an honest "not sure".
- Published infant-cry work reaching high accuracy typically uses cleaner, clinician-labelled data and often distinguishes pathological vs normal cries, not parent-reported hunger/tired. Do not claim clinical validity.

## Improving it (future work)
1. More and better-labelled data (ideally with nurse or clinician confirmation, ethics approval and parental consent).
2. Pretrained audio embeddings (e.g. wav2vec 2.0, AST, YAMNet/PANNs) with a small classifier head, or fine-tuning a CNN on mel-spectrograms.
3. Merge or redefine classes to what audio can actually support, add cry-vs-noise detection.
4. Arabic UI: move strings to translation files; the guidance text is isolated in `guidance.py`.
5. Have a pediatric nurse/clinician review all guidance text before any real use. Add NANDA-I mapping (see docs).
