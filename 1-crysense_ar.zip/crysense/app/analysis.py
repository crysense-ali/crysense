import os, sys, tempfile, subprocess
import numpy as np, joblib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from crysense_features import load_audio, extract_features, SR
import librosa

MODEL_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "model", "crysense_model.joblib")
_bundle = None
def bundle():
    global _bundle
    if _bundle is None:
        _bundle = joblib.load(MODEL_PATH)
    return _bundle

def load_any(path):
    """WAV/MP3/OGG/FLAC via librosa; falls back to ffmpeg for anything else (e.g. webm, m4a)."""
    try:
        return load_audio(path)
    except Exception:
        out = path + ".conv.wav"
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", path, "-ac", "1", "-ar", str(SR), out], check=True, timeout=60)
        try:
            return load_audio(out)
        finally:
            if os.path.exists(out): os.remove(out)

def analyze(path):
    y = load_any(path)
    feats = extract_features(y)           # raises ValueError for short/silent audio
    b = bundle()
    x = np.array([[feats[n] for n in b["feature_names"]]])
    proba = b["model"].predict_proba(x)[0]
    classes = b["classes"]; i = int(proba.argmax()); conf = float(proba[i]); top = classes[i]
    prior = b["priors"][top]
    reported = conf >= b["threshold"] and conf >= prior + b["lift"]
    pattern = top if reported else "uncertain"
    # waveform envelope for display
    env = librosa.feature.rms(y=y, frame_length=1024, hop_length=1024)[0]
    env = (env / (env.max() + 1e-9)).round(3).tolist()
    return {
        "pattern": pattern, "top_class": top, "confidence": conf, "base_rate": prior,
        "probabilities": {c: float(p) for c, p in zip(classes, proba)},
        "features": {
            "Duration (s)": round(feats["duration_s"], 1),
            "Active cry time (s)": round(feats["active_duration_s"], 1),
            "Mean pitch F0 (Hz)": round(feats["f0_mean"], 0),
            "Pitch range (Hz)": round(feats["f0_range"], 0),
            "Mean spectral centroid (Hz)": round(feats["centroid_mean"], 0),
            "Mean intensity (RMS, normalised)": round(feats["rms_mean"], 3),
        },
        "envelope": env,
    }
