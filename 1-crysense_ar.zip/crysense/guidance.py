"""Caregiver guidance + safety content. Wording is a plain-language summary of public guidance from:
 [1] NHS, Soothing a crying baby: https://www.nhs.uk/baby/caring-for-a-newborn/soothing-a-crying-baby/
 [2] AAP HealthyChildren, Abdominal Pain in Infants: https://www.healthychildren.org/English/health-issues/conditions/abdominal/Pages/Abdominal-Pains-in-Infants.aspx
 [3] AAP HealthyChildren, Responding to Your Baby's Cries: https://www.healthychildren.org/english/ages-stages/baby/crying-colic/pages/responding-to-your-babys-cries.aspx
 [4] WHO, Management of the sick young infant aged up to 2 months (IMCI chart booklet, 2019): https://www.who.int/publications/i/item/9789241516365
Content must be reviewed by a qualified pediatric nurse/clinician before any real-world use."""

SOURCES = [
    ("NHS: Soothing a crying baby", "https://www.nhs.uk/baby/caring-for-a-newborn/soothing-a-crying-baby/"),
    ("AAP HealthyChildren: Abdominal Pain in Infants", "https://www.healthychildren.org/English/health-issues/conditions/abdominal/Pages/Abdominal-Pains-in-Infants.aspx"),
    ("AAP HealthyChildren: Responding to Your Baby's Cries", "https://www.healthychildren.org/english/ages-stages/baby/crying-colic/pages/responding-to-your-babys-cries.aspx"),
    ("WHO: Management of the sick young infant aged up to 2 months (IMCI)", "https://www.who.int/publications/i/item/9789241516365"),
]

PATTERNS = {
    "hunger": {
        "label": "Hunger-related crying pattern",
        "interpretation": "The sound pattern is similar to recordings that parents labelled as hunger. Hunger is the most common reason babies cry.",
        "response": [
            "Check hunger cues: rooting, sucking on hands, lip smacking, turning the head toward the breast or bottle.",
            "Offer a feed, and check positioning and attachment if breastfeeding.",
            "If the baby cries during or around feeds, or is not interested in feeding, mention it to a health professional.",
        ],
    },
    "pain_distress": {
        "label": "Pain / distress-like crying pattern",
        "interpretation": "The sound pattern is similar to recordings labelled as tummy pain or distress. This can NOT tell pain from colic, illness or other causes.",
        "response": [
            "Check for a tight nappy, hair or clothing pressing on skin, and signs of trapped wind.",
            "Hold the baby close, sway gently, try gentle back stroking or a warm bath if the baby likes it.",
            "Crying that is high-pitched, constant, or 'not their normal cry' needs a clinical check. Do not wait for the app.",
        ],
    },
    "tiredness": {
        "label": "Sleepiness / fatigue-related pattern",
        "interpretation": "The sound pattern is similar to recordings labelled as tiredness.",
        "response": [
            "Reduce light, noise and stimulation; too much rocking or singing can keep a baby awake.",
            "Try gentle background noise, swaddle only if you know how to do it safely, and lay the baby down drowsy.",
            "Safe sleep: baby on their back, on a firm flat surface, nothing soft or loose in the cot.",
        ],
    },
    "discomfort": {
        "label": "Discomfort-related pattern",
        "interpretation": "The sound pattern is similar to recordings labelled as discomfort (including wind/burping and too hot or cold).",
        "response": [
            "Check the nappy.",
            "Check the room temperature and clothing: too hot or too cold?",
            "Try a different position, burp the baby, and check for anything uncomfortable on the skin.",
        ],
    },
    "uncertain": {
        "label": "Unknown / uncertain pattern",
        "interpretation": "The model could not identify a clear pattern with enough reliability, so no pattern is reported. This is expected often: the research dataset is small and its labels were given by parents.",
        "response": [
            "Do not rely on the sound alone. Go through the basics: hunger, nappy, tiredness, too hot/cold, wanting a cuddle, wind, overstimulation.",
            "Hold, soothe and reassess. Use your own observation of the baby first.",
            "If you cannot console the baby, or the cry sounds different from their normal cry, get a clinical assessment.",
        ],
    },
}

SAFETY_SIGNS = [
    ("breathing", "Difficulty breathing (fast breathing, grunting, chest pulling in)"),
    ("blue", "Bluish or very pale skin or lips"),
    ("poor_feeding", "Poor feeding or refusing feeds"),
    ("lethargy", "Unusually sleepy, floppy, hard to wake, or very few movements"),
    ("fever", "Fever (38 C / 100.4 F or higher) or abnormally low temperature in a young infant"),
    ("persistent", "Crying that is persistent, inconsolable, or not like their normal cry"),
]
EMERGENCY_TEXT = ("One or more danger signs selected. Do NOT wait for this app. Seek urgent medical assessment now "
                  "(call your local emergency number or go to the nearest emergency department). Egypt ambulance: 123.")
WHEN_TO_SEEK_HELP = [
    "Any danger sign above, at any time.",
    "A baby under 3 months with a fever or abnormally low temperature.",
    "Crying that is constant and cannot be consoled, or sounds different from their normal cry.",
    "Not interested in feeding, fewer wet nappies than usual, vomiting (especially green), or blood in stool.",
    "You feel unsure or overwhelmed. Asking for help is always reasonable. Never shake a baby; if you need a break, place the baby safely on their back in the cot and step away for a few minutes.",
]
DISCLAIMER = ("CrySense AI is a research prototype and a care-support aid. It is NOT a medical device and does not diagnose. "
              "Results are model-based possibilities, not causes.")
