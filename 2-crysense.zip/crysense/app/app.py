import os, sys, tempfile, json
from flask import Flask, render_template, request, jsonify
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import guidance
from analysis import analyze

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024
ALLOWED = {".wav", ".mp3", ".ogg", ".flac", ".m4a", ".webm", ".caf", ".3gp"}
METRICS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "model", "metrics.json")

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/analyze")
def analyze_page():
    return render_template("analyze.html", signs=guidance.SAFETY_SIGNS)

@app.post("/result")
def result():
    f = request.files.get("audio")
    if not f or not f.filename:
        return render_template("analyze.html", signs=guidance.SAFETY_SIGNS, error="Please record or upload a cry recording first."), 400
    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in ALLOWED:
        return render_template("analyze.html", signs=guidance.SAFETY_SIGNS, error="Unsupported file type. Use WAV or MP3."), 400
    info = {k: request.form.get(k, "").strip() for k in ("age", "feeding", "sleep", "diaper", "notes")}
    danger = request.form.getlist("danger")
    with tempfile.TemporaryDirectory() as d:     # audio is analysed in a temp folder and deleted immediately
        p = os.path.join(d, "upload" + ext); f.save(p)
        try:
            res = analyze(p)
        except ValueError as e:
            return render_template("analyze.html", signs=guidance.SAFETY_SIGNS, error=f"Could not analyse this audio: {e}"), 400
        except Exception:
            return render_template("analyze.html", signs=guidance.SAFETY_SIGNS, error="This audio file could not be read. Try a WAV or MP3 file."), 400
    young_flag = info["age"] == "0-4w" and "fever" in danger
    return render_template("result.html", res=res, p=guidance.PATTERNS[res["pattern"]], info=info,
                           danger=[l for k, l in guidance.SAFETY_SIGNS if k in danger], emergency=bool(danger),
                           emergency_text=guidance.EMERGENCY_TEXT, signs=guidance.SAFETY_SIGNS, G=guidance,
                           labels={k: v["label"] for k, v in guidance.PATTERNS.items()}, young_flag=young_flag)

@app.get("/safety")
def safety():
    return render_template("safety.html", signs=guidance.SAFETY_SIGNS, G=guidance)

@app.get("/about")
def about():
    m = json.load(open(METRICS)) if os.path.exists(METRICS) else None
    return render_template("about.html", m=m, G=guidance)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
