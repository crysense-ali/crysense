// On the result page the audio is gone after analysis, so switching language must not reload: swap the pre-rendered text instead.
(function(){
  var a=document.getElementById('langsw'); if(!a || !document.querySelector('[data-result]')) return;
  a.addEventListener('click',function(e){
    e.preventDefault();
    var h=document.documentElement, to=h.lang==='ar'?'en':'ar';
    h.lang=to; h.dir=to==='ar'?'rtl':'ltr';
    document.cookie='lang='+to+'; path=/; max-age=31536000; samesite=lax';
    a.textContent=to==='ar'?'English':'العربية';
    a.href='/lang/'+(to==='ar'?'en':'ar')+'?next=/analyze';
  });
})();
