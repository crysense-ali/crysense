# -*- coding: utf-8 -*-
"""English / Arabic text for the whole site. English text for guidance lives in guidance.py; Arabic is here."""
import guidance as G

LANGS = ("en", "ar")

UI = {
 "site": {"en": "CrySense AI", "ar": "كراي سينس AI"},
 "nav_analyze": {"en": "Analyze", "ar": "التحليل"},
 "nav_safety": {"en": "Safety signs", "ar": "علامات الخطر"},
 "nav_about": {"en": "About the model", "ar": "عن النموذج"},
 "switch": {"en": "العربية", "ar": "English"},
 "footer": {"en": "Research prototype, not a medical device. It does not diagnose. If you are worried about a baby, seek medical care.",
            "ar": "نموذج بحثي وليس جهازًا طبيًا. لا يشخّص الحالات. إذا كنت قلقًا على طفلك، اطلب الرعاية الطبية."},
 "h_sub": {"en": "Infant Cry Analysis & Responsive Care Assistant", "ar": "تحليل بكاء الرضّع ومساعد الرعاية المتجاوبة"},
 "h_intro": {"en": "Record or upload a baby's cry. A trained audio model looks at pitch, frequency, intensity, duration and sound patterns, then suggests a possible cry pattern with practical, source-based caregiver steps and clear warning signs.",
             "ar": "سجّل بكاء الطفل أو ارفع تسجيلًا له. يفحص نموذج صوتي مدرَّب درجة الصوت وتردده وشدته ومدته وأنماطه، ثم يقترح نمط بكاء محتملًا مع خطوات عملية للمُعتني مبنية على مصادر، وعلامات تحذير واضحة."},
 "start": {"en": "Start Analysis", "ar": "ابدأ التحليل"},
 "step1": {"en": "1. Baby details", "ar": "١. بيانات الطفل"},
 "step1d": {"en": "Age, last feed, sleep, nappy and your own observations.", "ar": "العمر، آخر رضعة، النوم، الحفاض وملاحظاتك الشخصية."},
 "step2": {"en": "2. Cry audio", "ar": "٢. صوت البكاء"},
 "step2d": {"en": "Record with the microphone or upload WAV/MP3.", "ar": "سجّل بالميكروفون أو ارفع ملف WAV أو MP3."},
 "step3": {"en": "3. Result + care guidance", "ar": "٣. النتيجة وإرشادات الرعاية"},
 "step3d": {"en": "Pattern, confidence, what to try, and when to get medical help.", "ar": "النمط، درجة الثقة، ما يمكن تجربته، ومتى تطلب المساعدة الطبية."},
 "important": {"en": "<b>Important:</b> CrySense AI does not diagnose. Patterns are model-based possibilities, not causes. When the model is not sure it says <i>Uncertain</i> instead of guessing.",
               "ar": "<b>مهم:</b> لا يقوم كراي سينس AI بالتشخيص. الأنماط احتمالات يقدّمها النموذج وليست أسبابًا مؤكدة. وعندما لا يكون النموذج متأكدًا يعرض <i>غير مؤكد</i> بدلًا من التخمين."},
 # analyze
 "a_title": {"en": "Start analysis", "ar": "ابدأ التحليل"},
 "a_s1": {"en": "1. Baby information", "ar": "١. معلومات الطفل"},
 "a_age": {"en": "Infant age", "ar": "عمر الطفل"},
 "a_feed": {"en": "Last feeding", "ar": "آخر رضعة"},
 "a_sleep": {"en": "Sleep status", "ar": "حالة النوم"},
 "a_diaper": {"en": "Diaper status", "ar": "حالة الحفاض"},
 "a_notes": {"en": "Caregiver observations (optional)", "ar": "ملاحظات المُعتني (اختياري)"},
 "a_notes_ph": {"en": "e.g. pulled legs up, hot room, spat up...", "ar": "مثال: ثنى رجليه، الغرفة حارة، تقيّأ قليلًا..."},
 "select": {"en": "Select...", "ar": "اختر..."},
 "a_s2": {"en": "2. Danger signs check", "ar": "٢. فحص علامات الخطر"},
 "a_s2d": {"en": "Tick any that apply right now. If any apply, get medical help without waiting for the analysis.", "ar": "حدّد أي علامة موجودة الآن. إذا وُجدت أي علامة فاطلب المساعدة الطبية دون انتظار التحليل."},
 "a_s3": {"en": "3. Cry audio", "ar": "٣. صوت البكاء"},
 "a_s3d": {"en": "Record 5 to 12 seconds of crying in a quiet place, close to the baby, or upload a file (WAV or MP3).", "ar": "سجّل من ٥ إلى ١٢ ثانية من البكاء في مكان هادئ وقريبًا من الطفل، أو ارفع ملفًا (WAV أو MP3)."},
 "rec_start": {"en": "Start recording", "ar": "ابدأ التسجيل"},
 "or": {"en": "or", "ar": "أو"},
 "analyze_btn": {"en": "Analyze cry", "ar": "حلّل البكاء"},
 "err_none": {"en": "Please record or upload a cry recording first.", "ar": "من فضلك سجّل البكاء أو ارفع تسجيلًا أولًا."},
 "err_type": {"en": "Unsupported file type. Use WAV or MP3.", "ar": "نوع الملف غير مدعوم. استخدم WAV أو MP3."},
 "err_short": {"en": "Could not analyse this audio: ", "ar": "تعذّر تحليل هذا الصوت: "},
 "err_read": {"en": "This audio file could not be read. Try a WAV or MP3 file.", "ar": "تعذّرت قراءة ملف الصوت. جرّب ملف WAV أو MP3."},
 # result
 "r_title": {"en": "Analysis result", "ar": "نتيجة التحليل"},
 "r_young": {"en": "Fever in a baby under 4 weeks needs urgent medical assessment.", "ar": "الحمّى عند طفل عمره أقل من ٤ أسابيع تستدعي تقييمًا طبيًا عاجلًا."},
 "r_detected": {"en": "Detected cry pattern", "ar": "نمط البكاء المكتشف"},
 "r_conf": {"en": "Confidence score:", "ar": "درجة الثقة:"},
 "r_conf2": {"en": "for the model's top guess", "ar": "لأعلى تخمين للنموذج"},
 "r_gate": {"en": "It did not pass the reliability gate, so no pattern is reported.", "ar": "لم تتجاوز حدّ الموثوقية، لذلك لا يتم عرض أي نمط."},
 "r_read_a": {"en": "How to read this: in the training data about", "ar": "كيف تقرأ هذه النتيجة: في بيانات التدريب كانت نحو"},
 "r_read_b": {"en": "of clips were of this top class, so a confidence close to that number means the model has learned little beyond that base rate. A pattern is only reported if the probability clearly beats the base rate.",
              "ar": "من المقاطع من هذه الفئة الأعلى، لذلك فإن ثقة قريبة من هذا الرقم تعني أن النموذج لم يتعلم الكثير بعد النسبة الأساسية. لا يُعرض نمط إلا إذا تجاوز احتماله النسبة الأساسية بوضوح."},
 "r_probs": {"en": "Model probabilities (not diagnoses)", "ar": "احتمالات النموذج (ليست تشخيصًا)"},
 "r_interp": {"en": "Possible interpretation", "ar": "التفسير المحتمل"},
 "r_resp": {"en": "Suggested caregiver response", "ar": "الاستجابة المقترحة للمُعتني"},
 "r_info": {"en": "Your information", "ar": "معلوماتك"},
 "r_obs": {"en": "Observations", "ar": "الملاحظات"},
 "r_ctx": {"en": "Context check (rule-based, not from the AI model): ", "ar": "فحص السياق (قائم على قواعد بسيطة، وليس من نموذج الذكاء الاصطناعي): "},
 "r_c_feed": {"en": "last feed was over 3 hours ago, so hunger is worth checking. ", "ar": "مرّت أكثر من ٣ ساعات على آخر رضعة، لذلك يستحق الجوع أن يُفحص. "},
 "r_c_diaper": {"en": "the nappy needs changing. ", "ar": "الحفاض يحتاج إلى تغيير. "},
 "r_c_sleep": {"en": "the baby may be overtired. ", "ar": "قد يكون الطفل مرهقًا من قلة النوم. "},
 "r_c_none": {"en": "nothing obvious from the answers given. ", "ar": "لا يوجد شيء واضح من الإجابات المدخلة. "},
 "r_feat": {"en": "Acoustic features measured", "ar": "الخصائص الصوتية المقاسة"},
 "r_when": {"en": "When to seek medical help", "ar": "متى تطلب المساعدة الطبية"},
 "r_allsigns": {"en": "See all safety signs", "ar": "اطّلع على كل علامات الخطر"},
 "r_from": {"en": "Guidance summarised from:", "ar": "الإرشادات ملخّصة من:"},
 "r_new": {"en": "New analysis", "ar": "تحليل جديد"},
 # safety
 "s_title": {"en": "Safety alerts: when not to rely on this app", "ar": "تنبيهات السلامة: متى لا تعتمد على هذا التطبيق"},
 "s_imm": {"en": "Seek medical assessment immediately, without waiting for any analysis, if the baby has:", "ar": "اطلب تقييمًا طبيًا فورًا، دون انتظار أي تحليل، إذا ظهر على الطفل:"},
 "s_also": {"en": "Also get advice if", "ar": "اطلب المشورة أيضًا إذا"},
 "s_sources": {"en": "Sources:", "ar": "المصادر (باللغة الإنجليزية):"},
 # about
 "ab_title": {"en": "About the model", "ar": "عن النموذج"},
 "ab_method": {"en": "<b>Method:</b> audio is resampled to 8 kHz and summarised into ~100 acoustic features (pitch, spectral centroid/bandwidth/rolloff, intensity, active cry duration, MFCCs). A Random Forest classifier trained on the Donate-a-Cry corpus outputs probabilities for hunger, pain/distress, tiredness and discomfort. Low-reliability results are shown as Uncertain.",
               "ar": "<b>الطريقة:</b> يُعاد أخذ عيّنات الصوت عند ٨ كيلوهرتز ويُلخَّص في نحو ١٠٠ خاصية صوتية (درجة الصوت، المركز الطيفي وعرض النطاق والانحدار الطيفي، الشدة، مدة البكاء الفعلي، وMFCC). يقدّم مصنِّف الغابة العشوائية (Random Forest) المدرَّب على مجموعة Donate-a-Cry احتمالات للجوع والألم/الضيق والتعب وعدم الارتياح. وتُعرض النتائج منخفضة الموثوقية على أنها غير مؤكدة."},
 "ab_data": {"en": "<b>Dataset:</b> Donate-a-Cry corpus (ODbL), cleaned and categorised by a KTH student project; labels were self-reported by parents.",
             "ar": "<b>البيانات:</b> مجموعة Donate-a-Cry (ترخيص ODbL)، نظّفها وصنّفها مشروع طلابي من KTH؛ وكانت التصنيفات من إفادة الآباء والأمهات أنفسهم."},
 "ab_eval": {"en": "Evaluation (grouped cross-validation, {n} clips)", "ar": "التقييم (تحقق متقاطع مجمَّع، {n} مقطعًا)"},
 "ab_acc": {"en": "Accuracy {a} (always guessing \"hunger\" scores {b}). Balanced accuracy {c} (chance = {d}). Macro F1 {e}.",
            "ar": "الدقة {a} (التخمين الدائم بـ«الجوع» يعطي {b}). الدقة المتوازنة {c} (الصدفة = {d}). مقياس Macro F1 = {e}."},
 "ab_honest": {"en": "<b>Honest reading:</b> the model does not reliably tell the classes apart. It is a working pipeline for research and teaching, not a validated tool.",
               "ar": "<b>القراءة الصريحة:</b> النموذج لا يميّز بين الفئات بشكل موثوق. هو مسار عمل تجريبي للبحث والتعليم، وليس أداة تم التحقق منها."},
 "ab_cm": {"en": "Confusion matrix", "ar": "مصفوفة الالتباس"},
}

# form option values stay in English (rule checks use them); only the label shown changes
AGE = {"0-4w": ("0 to 4 weeks", "من ٠ إلى ٤ أسابيع"), "4-8w": ("4 to 8 weeks", "من ٤ إلى ٨ أسابيع"),
       "2-6m": ("2 to 6 months", "من ٢ إلى ٦ أشهر"), "7m-2y": ("7 months to 2 years", "من ٧ أشهر إلى سنتين")}
FEEDING = [("Less than 1 hour ago", "منذ أقل من ساعة"), ("1 to 2 hours ago", "منذ ساعة إلى ساعتين"), ("2 to 3 hours ago", "منذ ساعتين إلى ٣ ساعات"),
           ("More than 3 hours ago", "منذ أكثر من ٣ ساعات"), ("Not sure", "غير متأكد")]
SLEEP = [("Just woke up", "استيقظ للتو"), ("Awake for under 1 hour", "مستيقظ منذ أقل من ساعة"), ("Awake for 1 to 2 hours", "مستيقظ منذ ساعة إلى ساعتين"),
         ("Awake for over 2 hours", "مستيقظ منذ أكثر من ساعتين"), ("Slept poorly / short naps", "نوم سيئ / قيلولات قصيرة")]
DIAPER = [("Clean and dry", "نظيف وجاف"), ("Wet", "مبلل"), ("Dirty", "متسخ"), ("Not checked yet", "لم يُفحص بعد")]
OPT = {en: ar for en, ar in FEEDING + SLEEP + DIAPER}

FEATURES = {"Duration (s)": "المدة (ثانية)", "Active cry time (s)": "زمن البكاء الفعلي (ثانية)", "Mean pitch F0 (Hz)": "متوسط درجة الصوت F0 (هرتز)",
            "Pitch range (Hz)": "مدى درجة الصوت (هرتز)", "Mean spectral centroid (Hz)": "متوسط المركز الطيفي (هرتز)",
            "Mean intensity (RMS, normalised)": "متوسط الشدة (RMS، مُطبَّع)"}

PATTERNS_AR = {
 "hunger": {"label": "نمط بكاء مرتبط بالجوع",
   "interpretation": "نمط الصوت يشبه تسجيلات صنّفها الآباء على أنها جوع. الجوع هو أكثر أسباب بكاء الرضّع شيوعًا.",
   "response": ["لاحظ علامات الجوع: البحث عن الثدي بالفم، مصّ اليدين، تحريك الشفتين، إدارة الرأس نحو الثدي أو الزجاجة.",
                "قدّم رضعة، وتأكد من وضعية الطفل والتقامه للثدي إذا كان يرضع طبيعيًا.",
                "إذا كان الطفل يبكي أثناء الرضعة أو حولها، أو لا يُظهر اهتمامًا بالرضاعة، فاذكر ذلك لأحد المختصين الصحيين."]},
 "pain_distress": {"label": "نمط بكاء يشبه الألم / الضيق",
   "interpretation": "نمط الصوت يشبه تسجيلات صنّفت على أنها ألم في البطن أو ضيق. لا يستطيع هذا التطبيق التفريق بين الألم والمغص والمرض وغيرها من الأسباب.",
   "response": ["تأكد من أن الحفاض ليس ضيقًا، وأن لا شيء من الشعر أو الملابس يضغط على الجلد، وابحث عن علامات الغازات المحبوسة.",
                "احمل الطفل قريبًا منك، وهزّه برفق، وجرّب التمسيد الخفيف على ظهره أو حمّامًا دافئًا إذا كان يحبه.",
                "البكاء الحاد أو المستمر أو «غير المعتاد لهذا الطفل» يحتاج إلى فحص طبي. لا تنتظر التطبيق."]},
 "tiredness": {"label": "نمط مرتبط بالنعاس / الإرهاق",
   "interpretation": "نمط الصوت يشبه تسجيلات صنّفت على أنها تعب.",
   "response": ["قلّل الضوء والضوضاء والتحفيز؛ فكثرة الهز أو الغناء قد تُبقي الطفل مستيقظًا.",
                "جرّب صوتًا هادئًا في الخلفية، ولفّ الطفل بالقماط فقط إذا كنت تعرف كيف تفعل ذلك بأمان، وضعه في سريره وهو ناعس.",
                "النوم الآمن: الطفل على ظهره، على سطح ثابت ومستوٍ، ولا شيء ناعم أو سائب في السرير."]},
 "discomfort": {"label": "نمط مرتبط بعدم الارتياح",
   "interpretation": "نمط الصوت يشبه تسجيلات صنّفت على أنها عدم ارتياح (ومنها الغازات/التجشؤ، أو الحرارة أو البرودة الزائدة).",
   "response": ["افحص الحفاض.",
                "افحص حرارة الغرفة وملابس الطفل: هل هو حارّ أكثر من اللازم أو بردان؟",
                "غيّر وضعية الطفل، ودعه يتجشأ، وتأكد من عدم وجود شيء يزعج جلده."]},
 "uncertain": {"label": "نمط غير معروف / غير مؤكد",
   "interpretation": "لم يستطع النموذج تحديد نمط واضح بموثوقية كافية، لذلك لا يُعرض أي نمط. هذا متوقع كثيرًا: فمجموعة بيانات البحث صغيرة وتصنيفاتها وضعها الآباء.",
   "response": ["لا تعتمد على الصوت وحده. راجع الأساسيات: الجوع، الحفاض، التعب، الحرارة أو البرودة، الرغبة في الحضن، الغازات، كثرة المؤثرات.",
                "احمل الطفل وهدّئه ثم أعد التقييم. اعتمد أولًا على ملاحظتك لطفلك.",
                "إذا لم تستطع تهدئته، أو بدا بكاؤه مختلفًا عن بكائه المعتاد، فاطلب تقييمًا طبيًا."]},
}

SIGNS_AR = {
 "breathing": "صعوبة في التنفس (تنفس سريع، أنين، انسحاب الصدر للداخل)",
 "blue": "زُرقة أو شحوب شديد في الجلد أو الشفتين",
 "poor_feeding": "ضعف الرضاعة أو رفض الرضعات",
 "lethargy": "نعاس غير معتاد، أو ارتخاء، أو صعوبة في إيقاظه، أو حركة قليلة جدًا",
 "fever": "حمّى (٣٨ درجة مئوية / ١٠٠٫٤ فهرنهايت أو أعلى) أو انخفاض غير طبيعي في الحرارة عند الرضيع الصغير",
 "persistent": "بكاء مستمر أو لا يمكن تهدئته أو يختلف عن بكائه المعتاد",
}
EMERGENCY_AR = ("تم تحديد علامة خطر أو أكثر. لا تنتظر هذا التطبيق. اطلب تقييمًا طبيًا عاجلًا الآن "
                "(اتصل برقم الطوارئ المحلي أو اذهب إلى أقرب قسم طوارئ). إسعاف مصر: ١٢٣.")
WHEN_AR = [
 "أي علامة خطر من المذكورة أعلاه، في أي وقت.",
 "طفل أقل من ٣ أشهر لديه حمّى أو انخفاض غير طبيعي في الحرارة.",
 "بكاء متواصل لا يمكن تهدئته، أو يبدو مختلفًا عن بكائه المعتاد.",
 "عدم الاهتمام بالرضاعة، أو قلة الحفاضات المبللة عن المعتاد، أو القيء (خاصة الأخضر)، أو وجود دم في البراز.",
 "إذا شعرت بالحيرة أو الإرهاق. طلب المساعدة أمر مقبول دائمًا. لا تهزّ الطفل أبدًا؛ وإذا احتجت إلى استراحة فضعه بأمان على ظهره في سريره وابتعد بضع دقائق.",
]
DISCLAIMER_AR = ("كراي سينس AI نموذج بحثي وأداة مساعدة للرعاية، وهو ليس جهازًا طبيًا ولا يقوم بالتشخيص. "
                 "النتائج احتمالات يقدّمها النموذج وليست أسبابًا مؤكدة.")
SOURCES_AR = ["NHS: تهدئة الطفل الباكي", "AAP HealthyChildren: ألم البطن عند الرضّع",
              "AAP HealthyChildren: كيف تستجيب لبكاء طفلك", "منظمة الصحة العالمية: التعامل مع الرضيع المريض حتى عمر شهرين (IMCI)"]

def t(key, lang, **kw):
    s = UI[key][lang]
    return s.format(**kw) if kw else s

def pattern(code, lang):
    return PATTERNS_AR[code] if lang == "ar" else G.PATTERNS[code]
def signs(lang):
    return [(k, SIGNS_AR[k] if lang == "ar" else l) for k, l in G.SAFETY_SIGNS]
def when(lang): return WHEN_AR if lang == "ar" else G.WHEN_TO_SEEK_HELP
def disclaimer(lang): return DISCLAIMER_AR if lang == "ar" else G.DISCLAIMER
def emergency(lang): return EMERGENCY_AR if lang == "ar" else G.EMERGENCY_TEXT
def sources(lang):
    return [(SOURCES_AR[i] if lang == "ar" else n, u) for i, (n, u) in enumerate(G.SOURCES)]
def opt(v, lang): return OPT.get(v, v) if lang == "ar" else v
def age(v, lang): return AGE[v][1 if lang == "ar" else 0] if v in AGE else v
def feat(k, lang): return FEATURES.get(k, k) if lang == "ar" else k

REASONS = {"Audio is shorter than 0.5 seconds.": "التسجيل أقصر من ٠٫٥ ثانية.", "Audio is silent.": "التسجيل صامت."}
def reason(msg, lang): return REASONS.get(msg, msg) if lang == "ar" else msg
