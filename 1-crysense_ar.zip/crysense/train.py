"""Train + evaluate the CrySense cry-pattern classifier (grouped cross-validation).
Usage: python train.py [path_to_cleaned_corpus]
Outputs: model/crysense_model.joblib, model/metrics.json, model/confusion_matrix.png
"""
import sys, os, json, glob, re
import numpy as np
import joblib
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedGroupKFold, GroupShuffleSplit
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, classification_report,
                             confusion_matrix, precision_recall_fscore_support)
from crysense_features import load_audio, extract_features

ROOT = sys.argv[1] if len(sys.argv) > 1 else "data/donateacry-corpus/donateacry_corpus_cleaned_and_updated_data"
# Folder -> app label. "burping" (8 clips) merged into discomfort; too few to stand alone.
FOLDER_TO_LABEL = {"hungry": "hunger", "belly_pain": "pain_distress", "tired": "tiredness",
                   "discomfort": "discomfort", "burping": "discomfort"}
SEED = 42

def speaker_id(fn):
    # filename starts with the app-instance UUID (36 chars); clips from one install ~ one family
    return re.match(r"^(.{36})-", os.path.basename(fn)).group(1).lower()

CACHE = "model/features_cache.npz"
if os.path.exists(CACHE):
    z = np.load(CACHE, allow_pickle=True); X, y, groups, names = z["X"], z["y"], z["groups"], list(z["names"])
else:
    X, y, groups, names = [], [], [], None
    for folder, label in FOLDER_TO_LABEL.items():
        for p in sorted(glob.glob(os.path.join(ROOT, folder, "*.wav"))):
            try:
                f = extract_features(load_audio(p))
            except ValueError as e:
                print("skip", p, e); continue
            names = names or sorted(f)
            X.append([f[n] for n in names]); y.append(label); groups.append(speaker_id(p))
    X, y, groups = np.array(X), np.array(y), np.array(groups)
    os.makedirs("model", exist_ok=True)
    np.savez(CACHE, X=X, y=y, groups=groups, names=np.array(names))
classes = sorted(set(y.tolist()))
print("clips:", len(y), {c: int((y == c).sum()) for c in classes}, "| distinct app installs:", len(set(groups)))

def candidates():
    return {
        "RandomForest": RandomForestClassifier(n_estimators=400, class_weight="balanced_subsample",
                                               min_samples_leaf=2, random_state=SEED, n_jobs=-1),
        "LogReg": make_pipeline(StandardScaler(), LogisticRegression(max_iter=3000, class_weight="balanced", C=0.5)),
    }

# EVALUATION: stratified, grouped 5-fold cross-validation over ALL clips. Every clip is predicted by a model that
# never saw it AND never saw any clip from the same app install (no family leakage). Out-of-fold predictions are
# pooled so every class (even the tiny ones) appears in the evaluation.
cv = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)
folds = list(cv.split(X, y, groups))
oof = {}
for name in candidates():
    P = np.zeros((len(y), len(classes)))
    for a, b in folds:
        m = candidates()[name].fit(X[a], y[a]); P[b] = m.predict_proba(X[b])
    oof[name] = P
    print(name, "OOF balanced acc", round(balanced_accuracy_score(y, np.array(classes)[P.argmax(1)]), 3))
best = max(oof, key=lambda n: balanced_accuracy_score(y, np.array(classes)[oof[n].argmax(1)]))
P = oof[best]; pred = np.array(classes)[P.argmax(1)]; conf = P.max(1)
rep = classification_report(y, pred, labels=classes, output_dict=True, zero_division=0)
cm = confusion_matrix(y, pred, labels=classes)
maj = max(classes, key=lambda c: (y == c).sum())
# Uncertain threshold: report accuracy on the clips the app would answer (conf >= thr) for several thresholds
UNCERTAIN_THRESHOLD = 0.50
# Base-rate-aware gate: the data is ~84% "hunger", so a raw probability of 0.8 for hunger carries no information.
# A pattern is only reported if its probability beats the class's base rate by LIFT and passes the floor.
prior = np.array([(y == c).mean() for c in classes]); LIFT = 0.10
gate_pass = (conf >= UNCERTAIN_THRESHOLD) & (conf >= prior[P.argmax(1)] + LIFT)
gated = {"rule": f"report only if prob >= {UNCERTAIN_THRESHOLD} and prob >= class base rate + {LIFT}; else 'uncertain'",
         "share_reported": float(gate_pass.mean()),
         "per_class": {c: {"reported": int(((pred == c) & gate_pass).sum()),
                           "correct_among_reported": int(((pred == c) & gate_pass & (y == c)).sum())} for c in classes}}
sweep = []
for t in (0.3, 0.4, 0.5, 0.6, 0.7):
    keep = conf >= t
    sweep.append({"threshold": t, "answered_share": float(keep.mean()),
                  "balanced_acc_on_answered": float(balanced_accuracy_score(y[keep], pred[keep])) if keep.sum() and len(set(y[keep])) > 1 else None})
metrics = {
    "dataset": "Donate-a-Cry corpus (cleaned/categorised KTH version), ODbL",
    "n_clips": int(len(y)), "class_counts": {c: int((y == c).sum()) for c in classes},
    "n_app_installs": int(len(set(groups))),
    "evaluation": "5-fold stratified GROUPED cross-validation (groups = app install id), out-of-fold predictions pooled over all clips, seed 42",
    "selected_model": best, "classes": classes,
    "balanced_accuracy_by_model": {n: float(balanced_accuracy_score(y, np.array(classes)[oof[n].argmax(1)])) for n in oof},
    "accuracy": float(accuracy_score(y, pred)),
    "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
    "majority_class_baseline_accuracy": float((y == maj).mean()),
    "chance_balanced_accuracy": 1 / len(classes),
    "macro_f1": float(rep["macro avg"]["f1-score"]),
    "per_class": {c: {k: float(rep[c][k]) for k in ("precision", "recall", "f1-score")} | {"support": int(rep[c]["support"])} for c in classes},
    "confusion_matrix": {"labels": classes, "matrix": cm.tolist()},
    "uncertain_threshold": UNCERTAIN_THRESHOLD, "threshold_sweep": sweep, "gate": gated, "base_rates": {c: float(p) for c, p in zip(classes, prior)},
}
final = candidates()[best].fit(X, y)
os.makedirs("model", exist_ok=True)
joblib.dump({"model": final, "feature_names": names, "classes": list(final.classes_),
             "threshold": UNCERTAIN_THRESHOLD, "priors": dict(zip(classes, prior.tolist())), "lift": LIFT, "trained_on": "Donate-a-Cry"}, "model/crysense_model.joblib")
json.dump(metrics, open("model/metrics.json", "w"), indent=2)
fig, ax = plt.subplots(figsize=(5.5, 4.5)); ax.imshow(cm, cmap="Blues")
ax.set_xticks(range(len(classes))); ax.set_xticklabels(classes, rotation=30, ha="right"); ax.set_yticks(range(len(classes))); ax.set_yticklabels(classes)
for i in range(len(classes)):
    for j in range(len(classes)): ax.text(j, i, cm[i, j], ha="center", va="center")
ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(f"Confusion matrix (grouped CV, {best})")
plt.tight_layout(); plt.savefig("model/confusion_matrix.png", dpi=150)
print(json.dumps({k: metrics[k] for k in ("selected_model","balanced_accuracy_by_model","accuracy","balanced_accuracy","majority_class_baseline_accuracy","macro_f1","per_class","confusion_matrix","threshold_sweep")}, indent=1))
