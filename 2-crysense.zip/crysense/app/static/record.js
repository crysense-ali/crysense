// Records from the microphone and encodes 16-bit mono WAV in the browser (no server-side codec needed).
const $ = id => document.getElementById(id);
let ctx, stream, proc, chunks = [], recording = false, t0, rate;
function setStatus(t){ const s=$('status'); s.hidden=false; s.textContent=t; }
function encodeWav(buf, sr){
  const n=buf.length, b=new ArrayBuffer(44+n*2), v=new DataView(b);
  const w=(o,s)=>[...s].forEach((c,i)=>v.setUint8(o+i,c.charCodeAt(0)));
  w(0,'RIFF');v.setUint32(4,36+n*2,true);w(8,'WAVE');w(12,'fmt ');v.setUint32(16,16,true);v.setUint16(20,1,true);v.setUint16(22,1,true);
  v.setUint32(24,sr,true);v.setUint32(28,sr*2,true);v.setUint16(32,2,true);v.setUint16(34,16,true);w(36,'data');v.setUint32(40,n*2,true);
  for(let i=0;i<n;i++){const x=Math.max(-1,Math.min(1,buf[i]));v.setInt16(44+i*2,x<0?x*0x8000:x*0x7fff,true);}
  return new Blob([v],{type:'audio/wav'});
}
function draw(data){ const c=$('wave'),g=c.getContext('2d'); c.width=c.clientWidth; g.clearRect(0,0,c.width,80); g.strokeStyle='#3b82c4'; g.beginPath();
  data.forEach((x,i)=>{const X=i/data.length*c.width; g.lineTo(X,40+x*38);}); g.stroke(); }
$('rec').onclick = async () => {
  if(!recording){
    try{ stream = await navigator.mediaDevices.getUserMedia({audio:true}); }catch(e){ setStatus('Microphone not available. Allow access (needs https or localhost) or upload a file instead.'); return; }
    ctx = new (window.AudioContext||window.webkitAudioContext)(); rate = ctx.sampleRate; chunks=[];
    const src = ctx.createMediaStreamSource(stream); proc = ctx.createScriptProcessor(4096,1,1);
    proc.onaudioprocess = e => { const d=new Float32Array(e.inputBuffer.getChannelData(0)); chunks.push(d); draw(d); $('timer').textContent=((Date.now()-t0)/1000).toFixed(0)+' s'; if(Date.now()-t0>15000) $('rec').click(); };
    src.connect(proc); proc.connect(ctx.destination); t0=Date.now(); recording=true; $('rec').textContent='Stop recording';
  } else {
    recording=false; proc.disconnect(); stream.getTracks().forEach(t=>t.stop()); ctx.close(); $('rec').textContent='Record again';
    const len=chunks.reduce((a,c)=>a+c.length,0), all=new Float32Array(len); let o=0; chunks.forEach(c=>{all.set(c,o);o+=c.length;});
    const file=new File([encodeWav(all,rate)],'recording.wav',{type:'audio/wav'}); const dt=new DataTransfer(); dt.items.add(file); $('file').files=dt.files;
    setStatus('Recording captured successfully ('+(len/rate).toFixed(1)+' s). Ready to analyze.');
  }
};
$('file').onchange = () => { const f=$('file').files[0]; if(f) setStatus('Audio file uploaded successfully: '+f.name+' ('+(f.size/1024).toFixed(0)+' KB). Ready to analyze.'); };
$('f').onsubmit = e => { if(!$('file').files.length){ e.preventDefault(); setStatus('Please record or upload a cry first.'); } else { $('go').textContent='Analyzing...'; $('go').disabled=true; } };
