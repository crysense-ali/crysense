import os, sys, tempfile, json
from flask import Flask, render_template, request, jsonify
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import guidance
from analysis import analyze
import i18n
from flask import redirect, make_response, g

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024
ALLOWED = {".wav", ".mp3", ".ogg", ".flac", ".m4a", ".webm", ".caf", ".3gp"}
METRICS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "model", "metrics.json")

@app.before_request
def pick_lang():
    c = request.cookies.get("lang")
    g.lang = c if c in i18n.LANGS else "en"

@app.context_processor
def ctx():
    L = g.get("lang", "en")
    return dict(lang=L, dir="rtl" if L == "ar" else "ltr", i18n=i18n,
                t=lambda k, l=None, **kw: i18n.t(k, l or L, **kw))

@app.get("/lang/<code>")
def set_lang(code):
    if code not in i18n.LANGS:
        code = "en"
    nxt = request.args.get("next", "/")
    if not nxt.startswith("/") or nxt.startswith("//") or nxt.startswith("/result"):
        nxt = "/analyze" if nxt.startswith("/result") else "/"
    r = make_response(redirect(nxt))
    r.set_cookie("lang", code, max_age=31536000, samesite="Lax")
    return r

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/analyze")
def analyze_page():
    return render_template("analyze.html", signs=i18n.signs(g.lang))

@app.post("/result")
def result():
    f = request.files.get("audio")
    if not f or not f.filename:
        return render_template("analyze.html", signs=i18n.signs(g.lang), error=i18n.t("err_none", g.lang)), 400
    ext = os.path.splitext(f.filename)[1].lower()
    if ext not in ALLOWED:
        return render_template("analyze.html", signs=i18n.signs(g.lang), error=i18n.t("err_type", g.lang)), 400
    info = {k: request.form.get(k, "").strip() for k in ("age", "feeding", "sleep", "diaper", "notes")}
    danger = request.form.getlist("danger")
    with tempfile.TemporaryDirectory() as d:     # audio is analysed in a temp folder and deleted immediately
        p = os.path.join(d, "upload" + ext); f.save(p)
        try:
            res = analyze(p)
        except ValueError as e:
            return render_template("analyze.html", signs=i18n.signs(g.lang), error=i18n.t("err_short", g.lang) + i18n.reason(str(e), g.lang)), 400
        except Exception:
            return render_template("analyze.html", signs=i18n.signs(g.lang), error=i18n.t("err_read", g.lang)), 400
    young_flag = info["age"] == "0-4w" and "fever" in danger
    return render_template("result.html", res=res, info=info, danger=danger, emergency=bool(danger),
                           labels={k: [i18n.pattern(k, l)["label"] for l in i18n.LANGS] for k in guidance.PATTERNS},
                           young_flag=young_flag)

@app.get("/safety")
def safety():
    return render_template("safety.html")

@app.get("/about")
def about():
    m = json.load(open(METRICS)) if os.path.exists(METRICS) else None
    return render_template("about.html", m=m)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
