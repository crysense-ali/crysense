#!/usr/bin/env bash
# Downloads the Donate-a-Cry corpus (ODbL) and the cleaned/categorised version used for training.
set -e
mkdir -p data && cd data
[ -d donateacry-corpus ] || git clone --depth 1 https://github.com/gveres/donateacry-corpus.git
echo "Done. Training data: data/donateacry-corpus/donateacry_corpus_cleaned_and_updated_data"
