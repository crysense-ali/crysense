# Dataset, method and evaluation

## Dataset
**Donate-a-Cry corpus** (Veres, G., 2015): cries uploaded by parents via a mobile app, each tagged by the parent with a suspected reason, baby age band and sex. License: ODbL / DbCL.
Source: https://github.com/gveres/donateacry-corpus
We use the cleaned version in the subfolder `donateacry_corpus_cleaned_and_updated_data` (KTH Speech Technology course project): converted to 8 kHz WAV, non-cry audio removed by listening, lonely/scared/unknown removed, cold/hot merged into discomfort, folders by class.

| Class (app) | Source folder(s) | Clips |
|---|---|---|
| Hunger | hungry | 382 |
| Discomfort | discomfort + burping (8 clips merged) | 35 |
| Tiredness | tired | 24 |
| Pain/distress | belly_pain | 16 |
| Total | | 457 from 221 app installs |

Limits: tiny and extremely imbalanced; labels are parents' guesses (not ground truth); recordings are of unknown quality; babies are mostly 0-2 months old; no clinical ground truth; "pain" here means "belly pain" tags only.

## Method
1. Load audio, resample to 8 kHz mono, cap at 12 s, peak-normalise.
2. Features (~100 per clip): intensity (RMS stats), active cry duration and ratio, pitch F0 via YIN (150-1200 Hz) on active frames (mean, std, min, max, range), spectral centroid / bandwidth / rolloff / flatness, zero-crossing rate, 13 MFCC mean+std, 13 delta-MFCC std.
3. Classifiers compared: Random Forest (400 trees, balanced class weights) and Logistic Regression (standardised, balanced). Random Forest scored higher and is shipped.
4. **Uncertainty gate:** report a pattern only if probability >= 0.50 and exceeds the class base rate by 0.10, otherwise "Unknown / Uncertain". Needed because 84% of the data is "hunger".
5. Confidence shown to the user is the model's predicted probability for its top class, with a note comparing it to the base rate. It is not a calibrated clinical probability.

## Evaluation (no train/test leakage)
5-fold stratified cross-validation grouped by app-install id (clips from the same install can never be in both train and test). Predictions from all held-out folds are pooled so even the tiny classes are tested. Final shipped model is refit on all clips; the reported numbers come only from held-out predictions. Full numbers: `model/metrics.json`; picture: `model/confusion_matrix.png`.

| Metric | Value |
|---|---|
| Accuracy | 0.836 (majority-class baseline 0.836) |
| Balanced accuracy | 0.250 (chance 0.25) |
| Macro F1 | 0.228 |
| Hunger precision / recall / F1 | 0.836 / 1.00 / 0.911 |
| Discomfort, tiredness, pain/distress | precision, recall, F1 all 0.00 |

Interpretation: on this data the features carry no usable signal for separating the parent-labelled reasons; the classifier falls back to the majority class. Report this openly in the project. Accuracy alone would be misleading, which is why precision, recall, F1, confusion matrix and balanced accuracy are given.

## Guidance and safety content sources
- NHS, Soothing a crying baby: https://www.nhs.uk/baby/caring-for-a-newborn/soothing-a-crying-baby/ (common reasons for crying, soothing methods, when crying may signal illness)
- AAP HealthyChildren, Abdominal Pain in Infants: https://www.healthychildren.org/English/health-issues/conditions/abdominal/Pages/Abdominal-Pains-in-Infants.aspx
- AAP HealthyChildren, Responding to Your Baby's Cries: https://www.healthychildren.org/english/ages-stages/baby/crying-colic/pages/responding-to-your-babys-cries.aspx
- WHO, Management of the sick young infant aged up to 2 months, IMCI chart booklet (2019): https://www.who.int/publications/i/item/9789241516365 (danger signs: not able to feed, fast breathing, severe chest indrawing, fever or low temperature, few movements, convulsions)

The text in `guidance.py` is a plain-language summary written for this prototype, not a quote, and needs clinical review.

## NANDA-I
NANDA International's taxonomy (e.g. 2021-2023, 12th ed.) is licensed material and its full definitions are not freely available, so it was **not** copied into the app. For the thesis, the student/supervisor can map each pattern to relevant NANDA-I diagnoses with licensed access (for example under Domain 2 Nutrition for feeding-related concerns and Domain 4 Activity/Rest for sleep-related ones: verify exact diagnosis names and codes in the book) and cite it as a nursing framework.

## Other references to consider
- Veres, G. (2015). Donate-a-Cry corpus. GitHub.
- A literature review on infant cry analysis and classification (e.g. Ji et al., 2021, EURASIP Journal on Audio, Speech, and Music Processing; verify the citation yourself before use).
- Wav2vec 2.0, AST, YAMNet for pretrained audio embeddings.
